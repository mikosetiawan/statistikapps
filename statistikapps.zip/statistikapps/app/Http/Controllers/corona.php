<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class corona extends Controller
{
    public function index()
    {
        $response = Http::get('https://kipi.covid19.go.id/api/get-province');
        $data = $response->json();
        dd($data);
    }
}
