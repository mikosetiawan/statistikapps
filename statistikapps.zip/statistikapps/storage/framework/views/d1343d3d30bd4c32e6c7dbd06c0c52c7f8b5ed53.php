<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> statistik | apps</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
    </script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">


</head>

<body>

    <div class="container py-5">
        <h1 class="text-center"><?php echo e($title); ?></h1>
        <h4 class="text-center"><?php echo e($referensi); ?></h4>
        <p class="text-center"><?php echo e($name); ?></p>
        <hr>
        <?php
            $api = file_get_contents("https://data.covid19.go.id/public/api/update.json");
            $data = json_decode($api ,true);

        ?>
        <div class="row py-3 px-3">
            <label for="" class="py-2"><b>TANGGAL UPDATE</b></label>
            <input type="text" class="form-control" value="<?php echo e($data['update']['penambahan']['created']); ?>" readonly>
        </div>
        <div class="row text-white shadow py-2 px-2 rounded text-center">
            <div class="col-lg-4 py-2">
                <div class="card card-color">
                    <h1 class="bi bi-people-fill"></h1>
                    <h2>Jumlah ODP</h2>
                    <div class="card-body">
                        <h3 class="card-title"><?php echo e($data['data']['jumlah_odp']); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 py-2">
                <div class="card card-color2">
                    <h1 class="bi bi-people-fill"></h1>
                    <h2>Jumlah PDP</h2>
                    <div class="card-body">
                        <h3 class="card-title"><?php echo e($data['data']['jumlah_pdp']); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 py-2">
                <div class="card card-color3">
                    <h1 class="bi bi-people-fill"></h1>
                    <h2>Jumlah Positif</h2>
                    <div class="card-body">
                        <h3 class="card-title"><?php echo e($data['update']['penambahan']['jumlah_positif']); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 py-2">
                <div class="card card-color4">
                    <h1 class="bi bi-people-fill"></h1>
                    <h2>Jumlah Meninggal</h2>
                    <div class="card-body">
                        <h3 class="card-title"><?php echo e($data['update']['penambahan']['jumlah_meninggal']); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 py-2">
                <div class="card card-color5">
                    <h1 class="bi bi-people-fill"></h1>
                    <h2>Jumlah Sembuh</h2>
                    <div class="card-body">
                        <h3 class="card-title"><?php echo e($data['update']['penambahan']['jumlah_sembuh']); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 py-2">
                <div class="card card-color6">
                    <h1 class="bi bi-people-fill"></h1>
                    <h2>Jumlah Dirawat</h2>
                    <div class="card-body">
                        <h3 class="card-title"><?php echo e($data['update']['penambahan']['jumlah_dirawat']); ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row py-2 my-3 px-2">
            <div class="col-lg-12">
                <button class="btn btn-warning" style="width:100%;" onclick="window.print()">LAPORAN</button>
            </div>
        </div>
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\statistikapps\resources\views/statistik.blade.php ENDPATH**/ ?>